package Language_Converter;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Code {
private WebDriver driver;
private BufferedReader wk_bufferedReader = null;
private BufferedWriter wk_bufferedWriter = null;
private String wk_fileLine = null;
private Pattern wk_pattern = null;
private Matcher wk_matcher = null;
private String wk_resultText = null;
private WebDriverWait wait = null;
private String wk_getConvertedText = null;
private String wk_filePath = null;
private String wk_resultDirPath = null;
private String wk_chromeDriverPath = null;
private String wk_outputFile = null;
private File wk_checkOutputFile = null;
private String wk_value = null;
private String wk_userName=null;
private String wk_Language=null;
private String wk_InputLocation = null;
private String wk_OutputLocation = null;
private String wk_chromedir = null;

// Get Location
public String getFiles() 
{
	Scanner input = new Scanner(System.in);
	System.out.println("Enter the Input Location: ");
	wk_InputLocation = input.nextLine();
	
	Scanner output = new Scanner(System.in);
	System.out.println("Enter the Output Location: ");
	wk_OutputLocation = output.nextLine();
	
	Scanner chrome = new Scanner(System.in);
	System.out.println("Enter the ChromeDriver Directory: ");
	wk_chromedir = chrome.nextLine();

// Getting file
File files = new File(wk_InputLocation);
File[] file = files.listFiles();
for (File Singlefile : file) 
{
	wk_pattern = Pattern.compile(".*/(.*)");
	wk_matcher = wk_pattern.matcher(Singlefile.toString());
	
	// This is to check Whether same name file exists or not
	if (wk_matcher.find()) 
	{
		wk_outputFile = wk_OutputLocation + "/" + wk_matcher.group(1);
		wk_checkOutputFile = new File(wk_outputFile);
		if (wk_checkOutputFile.exists()) 
		{
			wk_checkOutputFile.delete();
		}
	}
	readFiles(Singlefile.toString(), wk_outputFile.toString());
}
return "Success";
}
public String readFiles(String file, String outputFile) {
String wk_Result = null;
Scanner myObj = new Scanner(System.in);  // Create a Scanner object
System.out.println("Enter the Language in which you want to Convert:");

wk_userName = myObj.nextLine();  // Read user input
wk_Language="English to "+wk_userName;
//System.out.println("Language selected is: " + Language);  // Output user input
try {
	wk_bufferedReader = new BufferedReader(new FileReader(new File(file.toString())));
	wk_bufferedWriter = new BufferedWriter(new FileWriter(new File(outputFile)));
	wk_fileLine = wk_bufferedReader.readLine();
	while (wk_fileLine != null) 
	{
		if (!wk_fileLine.equalsIgnoreCase("msgid \"\"")) 
		{
			wk_pattern = Pattern.compile("msgstr.*?\"(.*)\"");
			wk_matcher = wk_pattern.matcher(wk_fileLine.toString());
			if (wk_matcher.find()) 
			{
				wk_resultText = wk_matcher.group(1);

if (wk_resultText != null) 
{
	SetBrowser(wk_chromedir);
	wk_Result = TextConvert(wk_resultText.toString());
	wk_bufferedWriter.write("msgstr \""+wk_Result.toString()+"\"");
	wk_bufferedWriter.newLine();
	wk_bufferedWriter.flush();
}
}
else
{
	wk_bufferedWriter.write(wk_fileLine.toString());
	wk_bufferedWriter.newLine();
	wk_bufferedWriter.flush();
}
}
else 
{
	wk_bufferedWriter.write(wk_fileLine.toString());
	wk_bufferedWriter.newLine();
	wk_bufferedWriter.flush();
}
wk_fileLine = wk_bufferedReader.readLine();
}
} 
catch (Exception e) 
{
	e.printStackTrace();
} 
finally 
{
try 
{
	wk_bufferedReader.close();
	wk_bufferedWriter.close();
}
catch (Exception e) 
{
	e.printStackTrace();
}
}
return "Work done";
}

public void SetBrowser(String chromeDriverPath) {
	
System.setProperty("webdriver.chrome.driver", chromeDriverPath);// need
driver = new ChromeDriver();
driver.manage().window().maximize();
}

public String TextConvert(String englisText) throws InterruptedException 
{
	wait = new WebDriverWait(driver, 30);
	driver.get("https://www.google.com/search?sxsrf=ALeKk00aFKUZBwUCfTHSn2gyN81bAh5GLQ%3A1602156138915&source=hp&ei=avZ-X-_ONZHiz7sP2s-UQA&q=English+to+Russian&oq=English+to+Russian&gs_lcp=CgZwc3ktYWIQAzIICAAQsQMQyQMyAggAMgIIADICCAAyAggAMgIIADICCAAyAggAMgIIADICCAA6CwgAELEDEIMBEMkDOggIABCxAxCDAToFCAAQsQM6DggAELEDEIMBEMkDEJECOgUIABCRAjoECAAQClCg2lpYv_laYMX7WmgAcAB4AIABqAOIAYcgkgEHMi05LjQuMZgBAKABAaoBB2d3cy13aXo&sclient=psy-ab&ved=0ahUKEwjvq6Hc8KTsAhUR8XMBHdonBQgQ4dUDCAc&uact=5");
//	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='q']")));
//	driver.findElement(By.xpath("//input[@name='q']")).sendKeys(wk_Language);
//	driver.findElement(By.xpath("/html/body/div[1]/div[2]/form/div[2]/div[1]/div[3]/center/input[1]")).click();
	driver.findElement(By.xpath("//textarea[@id='tw-source-text-ta']")).click();
	driver.findElement(By.xpath("//textarea[@id='tw-source-text-ta']")).sendKeys(englisText.toString().trim());
	Thread.sleep(3000);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//pre[@id='tw-target-text']//span")));
	String getConvertedText= driver.findElement(By.xpath("//pre[@id='tw-target-text']//span")).getText();
	try 
	{
		byte bytes[] = getConvertedText.getBytes("UTF-8");
		wk_value = new String(bytes, "UTF-8");
	} 
	catch (UnsupportedEncodingException e) 
	{
		e.printStackTrace();
	}
	driver.close();
	return wk_value;
}

public static void main(String[] args) {
	
    
new Code().getFiles();
}
}